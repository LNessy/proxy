# Growtopia Proxy
**My Discord: ProB1#0100**

This is a proxy for [Growtopia](https://growtopiagame.com/).

## 📜 Features
- [x] Fixed shadow ban
- [x] More Commands

## 📝 Requirements
- Visual Studio
- Microsoft Visual C++ Redistributable

## Credits
- Amateurz
